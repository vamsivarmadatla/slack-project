import React from "react";
import { Navbar, Nav, NavDropdown } from "react-bootstrap";
import "./Style.css";
import slack from "../img/slack.png";


const tColor = { color : '#1d1d1d' }


function Header() {
  return (
    <>
    <div class="navbar-header">
      <nav class="navbar navbar-expand-lg navbar-light">
      <a class="navbar-brand" href="#">
    <img src={slack} width="100" height="35" class="d-inline-block align-top" alt="slack-brand" loading="lazy"/>  
    </a>
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <ul class="navbar-nav mr-auto">      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" style={ tColor } id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Why Slack?
        </a>
        <div class="dropdown-menu" id="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Features</a>
          <a class="dropdown-item" href="#">Security</a>
          <a class="dropdown-item" href="#">Customers</a>
          <a class="dropdown-item" href="#">Slack Connect</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#" style={ tColor }>Solutions</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" style={ tColor } id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Resources
        </a>
        <div class="dropdown-menu" id="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="#">Resources Library</a>
          <a class="dropdown-item" href="#">Slack Tips</a>
          <a class="dropdown-item" href="#">Blog</a>
          <a class="dropdown-item" href="#">Webinars</a>
          <a class="dropdown-item" href="#">Slack Certified Program</a>
          <a class="dropdown-item" href="#">Help Center</a>
          <a class="dropdown-item" href="#">API</a>
          <a class="dropdown-item" href="#">App Directory</a>
          <a class="dropdown-item" href="#">Download</a>          
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#" style={ tColor }>Enterprise</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#" style={ tColor }>Pricing</a>
      </li>
      </ul>

      <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="#" style={ tColor }>Contact Sales</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#" style={ tColor }>Sign in</a>
      </li>
      <li class="nav-item">
        <a class="btn" href="#">TRY FOR FREE</a>
      </li>
      
    </ul>    
  </div>
</nav>
      </div>
    </>
  );
}

export default Header;
